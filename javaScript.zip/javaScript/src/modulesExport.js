// Named Exports
export let cores = []
export function getName(){}
export class Animais {}

// Lista de exportação
export { cores, getName, Animais}

// strict mode > como ficam todos os exports 

export default getCars() {

}


// export default getCars