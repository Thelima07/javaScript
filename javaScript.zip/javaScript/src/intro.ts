// boolean
// string 

// tuple
let title: [number, string]
title: ["1", "Título"]

// enum  { chave: valor}
enum Color {
    white = '#fff',
    red = '#f00',
    blue = '#00f'
}